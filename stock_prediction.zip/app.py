import os
import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from flask import Flask, render_template, request
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    mse = mae = None
    if request.method == 'POST':
        stock_symbol = request.form['symbol'].upper()

        today = datetime.date.today().strftime('%Y-%m-%d')
        data = yf.download(stock_symbol, start='2015-01-01', end=today)
        df = data[['Close']]

        scaler = MinMaxScaler()
        scaled_data = scaler.fit_transform(df)

        sequence_length = 60
        x_train, y_train = [], []
        for i in range(sequence_length, len(scaled_data) - 100):
            x_train.append(scaled_data[i-sequence_length:i, 0])
            y_train.append(scaled_data[i, 0])

        x_train = np.array(x_train)
        y_train = np.array(y_train)
        x_train = x_train.reshape((x_train.shape[0], x_train.shape[1], 1))

        model = Sequential([
            LSTM(50, return_sequences=True, input_shape=(x_train.shape[1], 1)),
            Dropout(0.2),
            LSTM(50),
            Dropout(0.2),
            Dense(1)
        ])

        model.compile(optimizer='adam', loss='mean_squared_error')
        model.fit(x_train, y_train, epochs=5, batch_size=32, verbose=0)

        test_data = scaled_data[-(sequence_length + 100):]
        x_test = []
        for i in range(sequence_length, len(test_data)):
            x_test.append(test_data[i-sequence_length:i, 0])

        x_test = np.array(x_test)
        x_test = x_test.reshape((x_test.shape[0], x_test.shape[1], 1))

        predictions = model.predict(x_test)
        predictions = scaler.inverse_transform(predictions)
        y_test = df[-100:].values

        mse = mean_squared_error(y_test, predictions)
        mae = mean_absolute_error(y_test, predictions)

        plt.figure(figsize=(10, 5))
        plt.plot(y_test, label='Actual')
        plt.plot(predictions, label='Predicted')
        plt.title(f'{stock_symbol} Stock Price Prediction')
        plt.xlabel('Time')
        plt.ylabel('Price (USD)')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        os.makedirs('static', exist_ok=True)
        plt.savefig('static/plot.png')
        plt.close()

    return render_template('index.html', mse=mse, mae=mae)

if __name__ == '__main__':
    app.run(debug=True)
