# Stock Price Prediction System

This is a real-time stock price prediction system using historical stock data and LSTM models.
It uses Yahoo Finance for data fetching and Flask for the web interface.
